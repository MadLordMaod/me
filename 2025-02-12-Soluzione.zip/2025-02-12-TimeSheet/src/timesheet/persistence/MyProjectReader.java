package timesheet.persistence;

import java.io.IOException;
import java.io.Reader;
import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.io.BufferedReader;


public class MyProjectReader implements ProjectReader {
	
	// Lezioni di Fondamenti T2		ore previste: 80
	// Lezioni di Linguaggi			ore previste: 64
	// Progetto Peonie				ore previste: 350
	// Progetto Innova				ore previste: 700
	
	public Map<String,Integer> projectHours(Reader reader) throws IOException, BadFileFormatException {
		Objects.requireNonNull(reader, "Input reader null in ProjectReader.projectHours");
		var bufferedReader = new BufferedReader(reader);
		var mappa = new HashMap<String,Integer>(); 
		String riga;
		while((riga=bufferedReader.readLine())!=null) {
			String[] items = riga.split("\t+|:");
			if (items.length!=3) throw new BadFileFormatException("Riga mal formattata, numero di elementi errato:" + riga);
			var projectName = items[0].trim();
			if (!items[1].trim().equals("ore previste")) throw new BadFileFormatException("Riga mal formattata, mancano le 'ore previste'");
			var hoursAsString = items[2].trim();
			int hours;
			try {
				hours = Integer.parseInt(hoursAsString);
				if (hours <= 0) throw new BadFileFormatException("Riga errata, le ore non possono essere nulle o negative: " + hoursAsString);
			}
			catch(NumberFormatException e) {
				throw new BadFileFormatException("Riga mal formattata, le ore non sono un intero valido: " + hoursAsString);
			}
			mappa.put(projectName, hours);
		}
		return mappa;
	}
	
}
