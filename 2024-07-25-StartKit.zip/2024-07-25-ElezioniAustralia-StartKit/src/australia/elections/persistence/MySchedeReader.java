package australia.elections.persistence;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.Reader;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Objects;
import java.util.Set;
import java.util.SortedMap;
import java.util.TreeMap;

import australia.elections.model.Scheda;

public class MySchedeReader implements SchedeReader {

	public List<Scheda> leggiSchede(Reader reader) throws IOException, BadFileFormatException {
		//
		// **** DA FARE ****
		//
		// non c’è alcun costruttore
		//
		// Il metodo leggiSchede legge le righe, memorizzando numero di elementi e nomi della prima riga 
		// per usarli poi come confronto per le righe successive, e le elabora estraendo i dati 
		// per costruire le singole schede, popolando quindi la lista da restituire.  
		//
		return null; // FAKE
	}


}
