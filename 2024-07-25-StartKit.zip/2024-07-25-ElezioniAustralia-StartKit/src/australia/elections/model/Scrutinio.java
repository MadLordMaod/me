package australia.elections.model;

import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Objects;
import java.util.stream.Collectors;

public class Scrutinio {

	private Map<String,List<Scheda>> mappa;
	private long totaleVoti;
	private StringBuilder logger;
	
	public Scrutinio(List<Scheda> schedeLette) {
		Objects.requireNonNull(schedeLette, "schede lette non possono essere null");
		if (schedeLette.isEmpty()) throw new IllegalArgumentException("La lista delle schede lette non può essere vuota");
		this.mappa = schedeLette.stream().collect(Collectors.groupingBy(
												scheda -> scheda.candidatiInOrdineDiPreferenza().get(0)
											));
		this.totaleVoti = schedeLette.size();
		this.logger = new StringBuilder();
	}
	
	public Risultato scrutina() {
		//  **** DA FARE ****
		// Il metodo incorpora la logica di scrutinio descritta nel Dominio del Problema e nel testo del compito
		// LEGGERE ATTENTAMENTE IL TESTO E I SUGGERIMENTI
		//
		return null; // FAKE
	}

	private boolean noMaggioranza(long maxVoti) {
		return maxVoti< totaleVoti/2 + 1;
	}
	
	public long getTotaleVoti() {
		return totaleVoti;
	}
	
	public String getLog() {
		return logger.toString();
	}
}
